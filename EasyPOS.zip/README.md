# POS
POS plugin for [Facturascripts 2018](https://www.facturascripts.com/) 
